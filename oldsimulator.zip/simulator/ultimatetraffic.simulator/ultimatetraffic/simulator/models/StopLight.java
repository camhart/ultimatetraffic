package ultimatetraffic.simulator.models;

import java.util.Iterator;
import java.util.TreeSet;

public class StopLight {
	double timeOfNextChange;
	Color currentLightColor;
	int lightId;
	double position;
	double stopPosition;
	TreeSet<Car> carsApproachingLight;
	public StopLight nextStopLight;
	
	public enum Color {
		GREEN, RED
	}
	
	public void moveCars(double timeChange) {
		
	}
	
	public void newIteration() {
		carsApproachingLight = new TreeSet<Car>();
		stopPosition = position;
	}

	public boolean changed(double timeStamp) {
		if(timeStamp >= timeOfNextChange) {
			if(currentLightColor == Color.GREEN) {
				currentLightColor = Color.RED;
			} else {
				currentLightColor = Color.GREEN;
			}
			return true;
		}
		return false;
	}

	public double getPosition() {
		return position;
	}

	public void setPosition(double position) {
		this.position = position;
	}
	
	public double getLightStopPosition() {
		Iterator<Car> iter = carsApproachingLight.iterator();
		double ret = this.position;
		Car curCar;
		while(iter.hasNext()) {
			curCar = iter.next();
			if(curCar.currentCommand == Car.Command.STOP) {
				ret-=Car.CAR_LENGTH;
			}
		}
		return ret;
	}
	
	
}
