package ultimatetraffic.simulator.models;

public class SpeedLimitSign {
	private int id;
	private double position;
	private int speed;

	public SpeedLimitSign(int id, double position, int speed) {
		this.id = id;
		this.position = position;
		this.speed = speed;
	}

	public double getPosition() {
		return this.position;
	}

	public int getSpeed() {
		return this.speed;
	}
}
