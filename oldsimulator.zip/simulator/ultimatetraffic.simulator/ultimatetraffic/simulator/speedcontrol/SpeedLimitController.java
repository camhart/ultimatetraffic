package ultimatetraffic.simulator.speedcontrol;

import java.util.ArrayList;

import ultimatetraffic.simulator.models.Car;
import ultimatetraffic.simulator.models.SpeedLimitSign;

public class SpeedLimitController implements SpeedController {

	ArrayList<SpeedLimitSign> signs;
	public SpeedLimitController(ArrayList<SpeedLimitSign> signs) {
		this.signs = signs;
	}
	
	@Override
	public void changeCarSpeed(Car car) {
		if(car.getDirection() == Car.Direction.EAST) {
			for(int c = 0; c < signs.size(); c++) {
				if(signs.get(c).getPosition() > car.getPosition()) {
					//car speed change
					car.setVelocity((double)signs.get(c - 1).getSpeed());
				}
			}
		}
	}

}
