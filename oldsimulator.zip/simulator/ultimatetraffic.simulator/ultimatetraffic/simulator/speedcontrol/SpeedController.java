package ultimatetraffic.simulator.speedcontrol;

import ultimatetraffic.simulator.models.Car;

public interface SpeedController {
//	public void changeCarSpeed(Car car);
	public 
}
