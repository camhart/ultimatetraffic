package car;
import java.util.ArrayList;
import java.io.*;

public class main {
	public static void main(String[] args) {
		
		Car car = new Car(0,0.01);
		double velocity = 27;
		ArrayList<Double> response = new ArrayList<Double>(); 
		String data = new String();
		StringBuilder s = new StringBuilder();
		
		for(double i=0; i<=30; i+=0.01){
			response.add(car.command(velocity, i));
		}
		
		for(int i=0; i<response.size(); i++){
			if(i<response.size()-1)
				s.append(String.valueOf(response.get(i))).append(",\n");
			else
				s.append(String.valueOf(response.get(i)));
		}
		
		data = s.toString();
		
		try {
			PrintWriter pw = new PrintWriter("data.csv", "UTF-8");
			pw.println(data);
			pw.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		System.out.println("DONE!");
	}
}
