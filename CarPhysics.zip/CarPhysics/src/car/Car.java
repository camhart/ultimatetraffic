package car;

public class Car {
	
	private double position;
	private double velocity;
	private double velocity_delayed;
	private double acceleration;
	private double acceleration_delayed;
	private double Kp;
	private double mass;
	private double damping;
	private double Fmax;
	private double Fmin;
	private double step;
	
	public Car(double initial_velocity, double time_step) {
		position = 0;
		velocity = initial_velocity;
		velocity_delayed = 0;
		acceleration = 0;
		acceleration_delayed = 0;
		Kp = 134;
		mass = 1270;
		damping = 5;
		Fmax = 2.85 * mass;
		Fmin = -0.938 * mass;
		step = time_step;
	}
	
	public double command(double command, double time){
		
		double error = command - velocity;
		double control = error * Kp;
		
		if(control > Fmax)
			control = Fmax;
		else if(control < Fmin)
			control = Fmin;
		
		velocity_delayed = velocity;
		acceleration_delayed = acceleration;
		
		acceleration = (control-damping*velocity)/mass;
		
		if(time > 0){
			velocity = velocity + step / 2 * (acceleration + acceleration_delayed);
			position = position + step / 2 * (velocity + velocity_delayed);
		}
		
		return velocity;
	}
	public double getPosition(){
		return position;
	}
	public double getVelocity(){
		return velocity;
	}
	public double getAcceleration(){
		return acceleration;
	}
}
